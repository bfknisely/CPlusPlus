#include <iostream>
#include "Machine.h"
using namespace std;

int main(){
	Machine device;
	cout << "Weight: " << device.getWeight() << endl;
	device.setWeight(20);
	cout << "Weight: " << device.getWeight() << endl;
}
