#ifndef MACHINE_H
#define MACHINE_H

Class Machine {
	
	public:
		Machine();
		int getWeight();
		void setWeight(int);
		
	private:
		int iWeight;
};

#endif
