#include <iostream>
#include "Machine.h"
using namespace std;

Machine::Machine() {
	iWeight=10;
	cout << "Machine constructed" << endl;
}

void Machine::setWeight(int x){
	iWeight = x;
}

int Machine::getWeight() {
	return iWeight;
}

Machine::~Machine() {
	cout << "Machine destroyed" << endl;
}
